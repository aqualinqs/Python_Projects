from django.contrib import admin
from .models import Stock, Funds
# Register your models here.
admin.site.register(Stock)
admin.site.register(Funds)