from django.apps import AppConfig


class FinancialPlannerConfig(AppConfig):
    name = 'financial_planner'
