from django.apps import AppConfig


class FmsappConfig(AppConfig):
    name = 'fmsapp'
